 //some statements
var someoutside = 'Hi class';
