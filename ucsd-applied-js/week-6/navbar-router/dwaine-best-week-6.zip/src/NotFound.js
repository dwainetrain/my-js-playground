import React from 'react';

const NotFound = () => {
    return(
        <div className="container">
            <h3>Nope, not here. 404.</h3>
        </div>
    )
}

export default NotFound;